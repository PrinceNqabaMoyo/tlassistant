def create_app():
    try:
        from flask import Flask
        from flask_cors import CORS
    except ModuleNotFoundError as e:
        raise ModuleNotFoundError(
            "Missing optional dependency required to run the API server. Install 'flask' (and 'flask-cors') to use create_app()."
        ) from e

    try:
        from .config import Config
    except ModuleNotFoundError as e:
        raise ModuleNotFoundError(
            "Missing optional dependency required to run the API server configuration. Install 'python-dotenv' to use create_app()."
        ) from e

    app = Flask(__name__)
    app.config.from_object(Config)
    CORS(app)

    # Register blueprints
    from .api.math import math_bp
    from .api.accounting import accounting_bp
    # from .api.curriculum import curriculum_bp  # Temporarily disabled due to ChromaDB issues
    from .api.thumbnails import thumbnails_bp
    from .api.payments import payments_bp
    from .api.statistics import stats_bp
    from .api.grade10_business_studies import grade10_business_studies_bp
    from .api.grade11_business_studies import grade11_business_studies_bp

    app.register_blueprint(math_bp, url_prefix='/api/math')
    app.register_blueprint(accounting_bp, url_prefix='/api/accounting')
    # app.register_blueprint(curriculum_bp, url_prefix='/api/curriculum')  # Temporarily disabled
    app.register_blueprint(thumbnails_bp, url_prefix='/api/thumbnails')
    app.register_blueprint(payments_bp, url_prefix='/api/payments')
    app.register_blueprint(stats_bp, url_prefix='/api/statistics')
    app.register_blueprint(grade10_business_studies_bp, url_prefix='/api/business-studies/grade10')
    app.register_blueprint(grade11_business_studies_bp, url_prefix='/api/business-studies/grade11')

    return app
